syntax match h1 "\zs\[.\+\]\ze"
highlight h1 ctermfg=red guifg=red cterm=bold gui=bold

autocmd Syntax txt syntax match mytxtSpecialStart "^\s*〇\zs.\+\ze\s" contained
autocmd Syntax txt highlight link mytxtSpecialStart Identifier

syntax region HighlightBlock start=/^-.*$/ end=/^-.*$/ keepend
highlight HighlightBlock ctermfg=yellow guifg=yellow
