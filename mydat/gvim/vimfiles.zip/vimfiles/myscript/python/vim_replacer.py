import pyvim as vim
import re



def replace_in_buffer(pattern):
    # 現在のバッファの内容を取得
    buf = vim.current.buffer
    buffertxt = buf[:]

    # 無名レジスタの内容を取得
    unknownregister = vim.eval('@"')

    # 無名レジスタの内容を改行で分割してリストにする
    replacelist = unknownregister.split('\n')

    # 正規表現パターンをコンパイル
    regex = re.compile(pattern)

    # バッファのテキストを置換
    matched_indexes = []
    for i, line in enumerate(buffertxt):
        matches = list(regex.finditer(line))
        for match in matches:
            if len(replacelist) > len(matched_indexes):
                start, end = match.span()
                line = line[:start] + replacelist[len(matched_indexes)] + line[end:]
                matched_indexes.append(match)
        buffertxt[i] = line

    # 置換後のテキストでバッファを更新
    buf[:] = buffertxt


# 仮定した関数の呼び出し
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        replace_in_buffer(sys.argv[1])